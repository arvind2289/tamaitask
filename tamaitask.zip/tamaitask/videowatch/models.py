from django.db import models

# Create your models here.
class Videolink(models.Model):
	id = models.AutoField(primary_key=True)
	video_title = models.CharField(max_length=64, blank=True, null=True)
	video_link = models.CharField(max_length=255, blank=True, null=True)
	#videofile = models.FileField(upload_to='documents/')
	#image = models.FileField(upload_to=documents/)



	"""docstring for Videos"""

		