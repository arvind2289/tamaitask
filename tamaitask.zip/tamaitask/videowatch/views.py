from django.shortcuts import render


from django.template import RequestContext
from django.shortcuts import render
from django.http import HttpResponse
from django.template import RequestContext
from .models import *
from django.template import Template
from django.core import serializers
from django.core.paginator import Paginator
from django.contrib.auth import login, authenticate
from django.contrib.auth.forms import UserCreationForm
from django.shortcuts import render, redirect
from .forms import SignUpForm

def Listview(request):
    listall = Videolink.objects.all() 
    paginator = Paginator(listall, 3)  
    page = request.GET.get('page')
    listall = paginator.get_page(page)
    return render(request, 'videowatch/index.html',{'listall':listall},)


def UrlsApi(request):
    listall = listall = Videolink.objects.all()   
    data = serializers.serialize('json', listall,indent=4)
    return HttpResponse(data, content_type='application/json')   

def home(request):
   
    return render(request, 'videowatch/landing.html')

def signup(request):
    if request.method == 'POST':
        form = SignUpForm(request.POST)
        if form.is_valid():
            form.save()
            username = form.cleaned_data.get('username')
            raw_password = form.cleaned_data.get('password1')
            user = authenticate(username=username, password=raw_password)
            login(request, user)
            return redirect('/listall')
    else:
        form = SignUpForm()
    return render(request, 'videowatch/signup.html', {'form': form})
