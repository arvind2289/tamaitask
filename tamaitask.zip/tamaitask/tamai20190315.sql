-- MySQL dump 10.13  Distrib 5.7.24, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: tamaitask
-- ------------------------------------------------------
-- Server version	5.7.24-0ubuntu0.16.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `auth_group`
--

DROP TABLE IF EXISTS `auth_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(80) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group`
--

LOCK TABLES `auth_group` WRITE;
/*!40000 ALTER TABLE `auth_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_group_permissions`
--

DROP TABLE IF EXISTS `auth_group_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_group_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_group_permissions_group_id_permission_id_0cd325b0_uniq` (`group_id`,`permission_id`),
  KEY `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` (`permission_id`),
  CONSTRAINT `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `auth_group_permissions_group_id_b120cbf9_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group_permissions`
--

LOCK TABLES `auth_group_permissions` WRITE;
/*!40000 ALTER TABLE `auth_group_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_permission`
--

DROP TABLE IF EXISTS `auth_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_permission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `content_type_id` int(11) NOT NULL,
  `codename` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_permission_content_type_id_codename_01ab375a_uniq` (`content_type_id`,`codename`),
  CONSTRAINT `auth_permission_content_type_id_2f476e4b_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_permission`
--

LOCK TABLES `auth_permission` WRITE;
/*!40000 ALTER TABLE `auth_permission` DISABLE KEYS */;
INSERT INTO `auth_permission` VALUES (1,'Can add log entry',1,'add_logentry'),(2,'Can change log entry',1,'change_logentry'),(3,'Can delete log entry',1,'delete_logentry'),(4,'Can view log entry',1,'view_logentry'),(5,'Can add group',2,'add_group'),(6,'Can change group',2,'change_group'),(7,'Can delete group',2,'delete_group'),(8,'Can view group',2,'view_group'),(9,'Can add permission',3,'add_permission'),(10,'Can change permission',3,'change_permission'),(11,'Can delete permission',3,'delete_permission'),(12,'Can view permission',3,'view_permission'),(13,'Can add user',4,'add_user'),(14,'Can change user',4,'change_user'),(15,'Can delete user',4,'delete_user'),(16,'Can view user',4,'view_user'),(17,'Can add content type',5,'add_contenttype'),(18,'Can change content type',5,'change_contenttype'),(19,'Can delete content type',5,'delete_contenttype'),(20,'Can view content type',5,'view_contenttype'),(21,'Can add session',6,'add_session'),(22,'Can change session',6,'change_session'),(23,'Can delete session',6,'delete_session'),(24,'Can view session',6,'view_session'),(25,'Can add videolink',7,'add_videolink'),(26,'Can change videolink',7,'change_videolink'),(27,'Can delete videolink',7,'delete_videolink'),(28,'Can view videolink',7,'view_videolink'),(29,'Can add profile',8,'add_profile'),(30,'Can change profile',8,'change_profile'),(31,'Can delete profile',8,'delete_profile'),(32,'Can view profile',8,'view_profile');
/*!40000 ALTER TABLE `auth_permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user`
--

DROP TABLE IF EXISTS `auth_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `password` varchar(128) NOT NULL,
  `last_login` datetime(6) DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `username` varchar(150) NOT NULL,
  `first_name` varchar(30) NOT NULL,
  `last_name` varchar(150) NOT NULL,
  `email` varchar(254) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user`
--

LOCK TABLES `auth_user` WRITE;
/*!40000 ALTER TABLE `auth_user` DISABLE KEYS */;
INSERT INTO `auth_user` VALUES (1,'pbkdf2_sha256$120000$0sjI5f1IHbx7$q7zbo+GfPtXpivuOSV0Q4lfYhewOwVtLuFH696m/S2o=','2019-03-15 06:33:23.527771',1,'arvind','','','arvind@gmail.com',1,1,'2019-03-14 06:49:03.190280'),(2,'pbkdf2_sha256$120000$a2Dh4pDOkDk3$LS7lvyWPVEghAcdtzfx5YfD8ORwa2ajx8REj1tmk5EQ=','2019-03-14 13:01:25.276532',0,'arvind2289','','','',0,1,'2019-03-14 13:01:24.723204'),(3,'aaaa',NULL,0,'aa','a','a','aa@gmil.com',0,1,'2019-03-14 17:53:17.608284'),(4,'admin@123',NULL,0,'arvindpwt','arvind','yadav','arvind@pwt.in',0,1,'2019-03-14 17:55:35.367233'),(5,'pbkdf2_sha256$120000$y4oiemesjITd$qVvhzdWvt1xM12oV6xBpbwxtzY+/q3W6bhvj8+qPkNQ=','2019-03-14 18:01:51.896870',0,'arvinda21','arvind','yadav','arvind.yadav1@livehopper.com',1,1,'2019-03-14 18:01:51.335724'),(6,'pbkdf2_sha256$120000$yq70c2nZjzqF$vmhl/KQJIbfgOstPqnoU/fVohDSiahq0AOdh2PNQakQ=','2019-03-14 18:19:03.347885',0,'pintu','saurabhrai','sir','74rai.saurabh@gamil.com',0,1,'2019-03-14 18:16:25.931438'),(7,'pbkdf2_sha256$120000$aRRNZQdTmmRW$5H3Kad3dMwEmseOwEIZ6ucU34z2lA2ay2AsiXLyG4Rw=',NULL,1,'tamaitask','','','arvind@gamil.com',1,1,'2019-03-15 07:23:31.548052'),(8,'pbkdf2_sha256$120000$YK8e2R4dzGeM$hFRCsM5dkX2uXxILT+elFy4KOf9mFU+VQOQbTyfPML8=','2019-03-15 07:38:16.259050',0,'arvindtest','arvind','yadav','arvind22@gmail.com',0,1,'2019-03-15 07:38:15.716291');
/*!40000 ALTER TABLE `auth_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user_groups`
--

DROP TABLE IF EXISTS `auth_user_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_user_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_user_groups_user_id_group_id_94350c0c_uniq` (`user_id`,`group_id`),
  KEY `auth_user_groups_group_id_97559544_fk_auth_group_id` (`group_id`),
  CONSTRAINT `auth_user_groups_group_id_97559544_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  CONSTRAINT `auth_user_groups_user_id_6a12ed8b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user_groups`
--

LOCK TABLES `auth_user_groups` WRITE;
/*!40000 ALTER TABLE `auth_user_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_user_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user_user_permissions`
--

DROP TABLE IF EXISTS `auth_user_user_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_user_user_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_user_user_permissions_user_id_permission_id_14a6b632_uniq` (`user_id`,`permission_id`),
  KEY `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` (`permission_id`),
  CONSTRAINT `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user_user_permissions`
--

LOCK TABLES `auth_user_user_permissions` WRITE;
/*!40000 ALTER TABLE `auth_user_user_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_user_user_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_admin_log`
--

DROP TABLE IF EXISTS `django_admin_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_admin_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `action_time` datetime(6) NOT NULL,
  `object_id` longtext,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint(5) unsigned NOT NULL,
  `change_message` longtext NOT NULL,
  `content_type_id` int(11) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `django_admin_log_content_type_id_c4bce8eb_fk_django_co` (`content_type_id`),
  KEY `django_admin_log_user_id_c564eba6_fk_auth_user_id` (`user_id`),
  CONSTRAINT `django_admin_log_content_type_id_c4bce8eb_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  CONSTRAINT `django_admin_log_user_id_c564eba6_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_admin_log`
--

LOCK TABLES `django_admin_log` WRITE;
/*!40000 ALTER TABLE `django_admin_log` DISABLE KEYS */;
INSERT INTO `django_admin_log` VALUES (1,'2019-03-14 06:52:45.587299','1','Videolink object (1)',1,'[{\"added\": {}}]',7,1),(2,'2019-03-14 09:57:48.232028','2','Videolink object (2)',1,'[{\"added\": {}}]',7,1),(3,'2019-03-14 09:58:12.772215','3','Videolink object (3)',1,'[{\"added\": {}}]',7,1),(4,'2019-03-14 09:58:31.047840','4','Videolink object (4)',1,'[{\"added\": {}}]',7,1),(5,'2019-03-14 09:58:42.340281','5','Videolink object (5)',1,'[{\"added\": {}}]',7,1),(6,'2019-03-14 09:59:48.263613','6','Videolink object (6)',1,'[{\"added\": {}}]',7,1),(7,'2019-03-14 10:00:18.844631','7','Videolink object (7)',1,'[{\"added\": {}}]',7,1),(8,'2019-03-14 10:00:48.026846','8','Videolink object (8)',1,'[{\"added\": {}}]',7,1),(9,'2019-03-14 11:39:39.141687','1','Videolink object (1)',2,'[{\"changed\": {\"fields\": [\"video_link\"]}}]',7,1),(10,'2019-03-14 11:39:47.819153','2','Videolink object (2)',2,'[]',7,1),(11,'2019-03-14 11:39:59.244902','3','Videolink object (3)',2,'[]',7,1),(12,'2019-03-14 11:40:06.631378','4','Videolink object (4)',2,'[]',7,1),(13,'2019-03-14 11:40:14.111716','5','Videolink object (5)',2,'[]',7,1),(14,'2019-03-14 11:40:20.329660','6','Videolink object (6)',2,'[{\"changed\": {\"fields\": [\"video_link\"]}}]',7,1),(15,'2019-03-14 11:40:27.342404','6','Videolink object (6)',2,'[]',7,1),(16,'2019-03-14 11:40:35.554264','7','Videolink object (7)',2,'[{\"changed\": {\"fields\": [\"video_link\"]}}]',7,1),(17,'2019-03-14 11:40:56.090467','7','Videolink object (7)',2,'[]',7,1),(18,'2019-03-14 11:41:03.790437','8','Videolink object (8)',2,'[{\"changed\": {\"fields\": [\"video_link\"]}}]',7,1),(19,'2019-03-14 11:48:09.555975','1','Videolink object (1)',2,'[{\"changed\": {\"fields\": [\"video_title\"]}}]',7,1),(20,'2019-03-14 11:48:34.368987','2','Videolink object (2)',2,'[{\"changed\": {\"fields\": [\"video_title\"]}}]',7,1),(21,'2019-03-14 11:48:44.077810','3','Videolink object (3)',2,'[{\"changed\": {\"fields\": [\"video_title\"]}}]',7,1),(22,'2019-03-14 11:48:53.540406','4','Videolink object (4)',2,'[{\"changed\": {\"fields\": [\"video_title\"]}}]',7,1),(23,'2019-03-14 11:49:03.194129','5','Videolink object (5)',2,'[{\"changed\": {\"fields\": [\"video_title\"]}}]',7,1),(24,'2019-03-14 11:49:17.973083','6','Videolink object (6)',2,'[{\"changed\": {\"fields\": [\"video_title\"]}}]',7,1),(25,'2019-03-14 11:49:28.392202','7','Videolink object (7)',2,'[{\"changed\": {\"fields\": [\"video_title\"]}}]',7,1),(26,'2019-03-14 11:49:39.370802','8','Videolink object (8)',2,'[{\"changed\": {\"fields\": [\"video_title\"]}}]',7,1),(27,'2019-03-14 20:19:30.988269','1','Videolink object (1)',2,'[{\"changed\": {\"fields\": [\"video_link\"]}}]',7,1),(28,'2019-03-14 20:23:13.784857','1','Videolink object (1)',2,'[{\"changed\": {\"fields\": [\"video_link\"]}}]',7,1),(29,'2019-03-14 20:23:42.469695','1','Videolink object (1)',2,'[{\"changed\": {\"fields\": [\"video_link\"]}}]',7,1),(30,'2019-03-14 20:33:22.808250','1','Videolink object (1)',2,'[{\"changed\": {\"fields\": [\"video_link\"]}}]',7,1),(31,'2019-03-14 20:36:41.592940','1','Videolink object (1)',2,'[{\"changed\": {\"fields\": [\"video_link\"]}}]',7,1),(32,'2019-03-15 06:33:54.081929','1','Videolink object (1)',2,'[]',7,1),(33,'2019-03-15 07:03:29.722709','1','Videolink object (1)',2,'[{\"changed\": {\"fields\": [\"video_link\"]}}]',7,1),(34,'2019-03-15 07:13:24.906797','1','Videolink object (1)',2,'[{\"changed\": {\"fields\": [\"video_link\"]}}]',7,1),(35,'2019-03-15 07:16:44.862131','4','Videolink object (4)',2,'[{\"changed\": {\"fields\": [\"video_link\"]}}]',7,1),(36,'2019-03-15 07:16:59.106620','4','Videolink object (4)',2,'[]',7,1),(37,'2019-03-15 07:17:27.912131','6','Videolink object (6)',2,'[{\"changed\": {\"fields\": [\"video_link\"]}}]',7,1),(38,'2019-03-15 07:17:47.320338','3','Videolink object (3)',2,'[{\"changed\": {\"fields\": [\"video_link\"]}}]',7,1);
/*!40000 ALTER TABLE `django_admin_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_content_type`
--

DROP TABLE IF EXISTS `django_content_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_content_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `django_content_type_app_label_model_76bd3d3b_uniq` (`app_label`,`model`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_content_type`
--

LOCK TABLES `django_content_type` WRITE;
/*!40000 ALTER TABLE `django_content_type` DISABLE KEYS */;
INSERT INTO `django_content_type` VALUES (1,'admin','logentry'),(2,'auth','group'),(3,'auth','permission'),(4,'auth','user'),(5,'contenttypes','contenttype'),(6,'sessions','session'),(8,'videowatch','profile'),(7,'videowatch','videolink');
/*!40000 ALTER TABLE `django_content_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_migrations`
--

DROP TABLE IF EXISTS `django_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_migrations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applied` datetime(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_migrations`
--

LOCK TABLES `django_migrations` WRITE;
/*!40000 ALTER TABLE `django_migrations` DISABLE KEYS */;
INSERT INTO `django_migrations` VALUES (1,'contenttypes','0001_initial','2019-03-14 06:24:42.588894'),(2,'auth','0001_initial','2019-03-14 06:24:55.353770'),(3,'admin','0001_initial','2019-03-14 06:24:58.096108'),(4,'admin','0002_logentry_remove_auto_add','2019-03-14 06:24:58.166842'),(5,'admin','0003_logentry_add_action_flag_choices','2019-03-14 06:24:58.246816'),(6,'contenttypes','0002_remove_content_type_name','2019-03-14 06:24:59.833206'),(7,'auth','0002_alter_permission_name_max_length','2019-03-14 06:25:00.000850'),(8,'auth','0003_alter_user_email_max_length','2019-03-14 06:25:00.179200'),(9,'auth','0004_alter_user_username_opts','2019-03-14 06:25:00.242015'),(10,'auth','0005_alter_user_last_login_null','2019-03-14 06:25:01.058948'),(11,'auth','0006_require_contenttypes_0002','2019-03-14 06:25:01.170133'),(12,'auth','0007_alter_validators_add_error_messages','2019-03-14 06:25:01.321645'),(13,'auth','0008_alter_user_username_max_length','2019-03-14 06:25:01.515506'),(14,'auth','0009_alter_user_last_name_max_length','2019-03-14 06:25:01.738322'),(15,'sessions','0001_initial','2019-03-14 06:25:02.597366'),(16,'videowatch','0001_initial','2019-03-14 06:25:03.071341'),(17,'videowatch','0002_profile','2019-03-14 17:54:29.628615');
/*!40000 ALTER TABLE `django_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_session`
--

DROP TABLE IF EXISTS `django_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime(6) NOT NULL,
  PRIMARY KEY (`session_key`),
  KEY `django_session_expire_date_a5c62663` (`expire_date`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_session`
--

LOCK TABLES `django_session` WRITE;
/*!40000 ALTER TABLE `django_session` DISABLE KEYS */;
INSERT INTO `django_session` VALUES ('0s1rlpoepkk7del7hgiw17e7xgsh9vwr','NTg5MzUwNGYyMDQ5MGRjYWU5M2I0YjFiZjM4YWFlYzY0ODA3NzE1OTp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9pZCI6IjgiLCJfYXV0aF91c2VyX2hhc2giOiI4MmJlNWUyNzM5ZjU0NzBlNjBmMjE5YTEwNjQ2MDJjY2Y2MDIwYmZkIn0=','2019-03-29 07:38:16.398210'),('1p1ypnd9u3zz8hlb3lle6x9ilba4wflb','YzI2NDA5NjU2YjMwMmM0YmI0OGExOTUyZGQ5ZjFiMWU4ZmQ2NzQ5MTp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiMmNhZDI1YzUxYzlmZDY5ZDc0ZGIyZWM4NmVmMThmODQxZWQ2ZjhlNiIsIl9hdXRoX3VzZXJfaWQiOiIxIn0=','2019-03-28 20:12:10.515612'),('5fvn575ianc6j4rwkgu8jlp8esng9rsy','ZGUzNjczZDk1NzVmM2U2M2MzYWM3YWI4ZTgzNDQxNTI2ODA5MjQ1ODp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiIyY2FkMjVjNTFjOWZkNjlkNzRkYjJlYzg2ZWYxOGY4NDFlZDZmOGU2In0=','2019-03-28 17:37:59.664435');
/*!40000 ALTER TABLE `django_session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `videowatch_profile`
--

DROP TABLE IF EXISTS `videowatch_profile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `videowatch_profile` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `address` varchar(50) DEFAULT NULL,
  `city` varchar(40) DEFAULT NULL,
  `post` varchar(40) DEFAULT NULL,
  `token` varchar(15) DEFAULT NULL,
  `subscribed` varchar(2) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`),
  UNIQUE KEY `token` (`token`),
  CONSTRAINT `videowatch_profile_user_id_f2f43ea7_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `videowatch_profile`
--

LOCK TABLES `videowatch_profile` WRITE;
/*!40000 ALTER TABLE `videowatch_profile` DISABLE KEYS */;
/*!40000 ALTER TABLE `videowatch_profile` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `videowatch_videolink`
--

DROP TABLE IF EXISTS `videowatch_videolink`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `videowatch_videolink` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `video_title` varchar(64) DEFAULT NULL,
  `video_link` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `videowatch_videolink`
--

LOCK TABLES `videowatch_videolink` WRITE;
/*!40000 ALTER TABLE `videowatch_videolink` DISABLE KEYS */;
INSERT INTO `videowatch_videolink` VALUES (1,'Tutorial 1','https://download.videvo.net/videvo_files/video/premium/video0029/small_watermarked/lulu_headphones00_preview.mp4'),(2,'Tutorial Dummy 2','https://sample-videos.com/video123/mp4/720/big_buck_bunny_720p_1mb.mp4'),(3,'Tutorial Dummy 3','https://www.videvo.net/videvo_files/converted/2012_09/videos/hd0456.mov57012.mp4'),(4,'Tutorial Dummy 4','https://www.videvo.net/videvo_files/converted/2012_09/videos/hd0456.mov57012.mp4'),(5,'Tutorial Dummy 5','https://sample-videos.com/video123/mp4/720/big_buck_bunny_720p_1mb.mp4'),(6,'Tutorial Dummy 6','https://www.videvo.net/videvo_files/converted/2012_09/videos/hd0456.mov57012.mp4'),(7,'Tutorial Dummy 7','https://sample-videos.com/video123/mp4/720/big_buck_bunny_720p_1mb.mp4'),(8,'Tutorial Dummy 8','https://sample-videos.com/video123/mp4/720/big_buck_bunny_720p_1mb.mp4');
/*!40000 ALTER TABLE `videowatch_videolink` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-03-15 13:38:48
