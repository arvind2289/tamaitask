from django.apps import AppConfig


class VideowatchConfig(AppConfig):
    name = 'videowatch'
