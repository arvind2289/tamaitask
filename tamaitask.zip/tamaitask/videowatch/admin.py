from django.contrib import admin

# Register your models here.
from .models import Videolink
#from videowatch.models import Videolink

#admin.site.register(Videolink)

#admin.site.register(Videolink)

class VideolinkAdmin(admin.ModelAdmin):
    list_display = ('id','video_title', 'video_link')

admin.site.register(Videolink, VideolinkAdmin)
