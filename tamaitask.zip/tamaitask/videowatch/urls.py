from django.urls import path

from . import views
#fcore import views as core_views

urlpatterns = [
    path('', views.home, name='home'),
    path('signup', views.signup, name='signup'),
    path('listall', views.Listview, name='Listview'),
    path('UrlsApi',views.UrlsApi , name='UrlsApi')
   
]